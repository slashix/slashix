from app import bot

from handlers.users.start import *
from handlers.users.search_zaim import *
from handlers.users.zaim_for_null import *
from handlers.users.instructions import *

from handlers.admin.admin_panel import *
from handlers.admin.send import *
from handlers.admin.refscount import *
from handlers.admin.refs import *
from handlers.admin.blocked import *

bot.polling(none_stop=True, timeout=60)