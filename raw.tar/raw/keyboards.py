from telebot.types import ReplyKeyboardMarkup, InlineKeyboardMarkup, KeyboardButton, InlineKeyboardButton

main_menu = KeyboardButton('Главное меню')

start_markup = ReplyKeyboardMarkup(resize_keyboard=True, row_width=1)
start_button1 = KeyboardButton('Подобрать займ')
start_button2 = KeyboardButton('Займы под 0%')
start_button3 = KeyboardButton('Инструкция')
start_markup.add(*[start_button1, start_button2, start_button3])

sum_markup = ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
sum_button1 = KeyboardButton('15.000 руб. 💸')
sum_button2 = KeyboardButton('30.000 руб. 💸')
sum_button3 = KeyboardButton('70.000 руб. 💸')
sum_button4 = KeyboardButton('100.000 руб. 💸')
sum_markup.add(*[sum_button1, sum_button2, sum_button3, sum_button4])
sum_markup.row(main_menu)


works_markup = ReplyKeyboardMarkup(resize_keyboard=True, row_width=1)
works_button1 = KeyboardButton('Да, трудоустроен(а)')
works_button2 = KeyboardButton('Нет, не трудоустроен(а)')
works_markup.add(*[works_button1, works_button2, main_menu])

delay_markup = ReplyKeyboardMarkup(resize_keyboard=True, row_width=1)
delay_button1 = KeyboardButton('Нет просрочек')
delay_button2 = KeyboardButton('Да, есть 1')
delay_button3 = KeyboardButton('Да, есть 2-3')
delay_markup.add(*[delay_button1, delay_button2, delay_button3, main_menu])


admin_markup = InlineKeyboardMarkup(row_width=1)
admin_button1 = InlineKeyboardButton(text='Рассылка', callback_data='admin|send')
admin_button2 = InlineKeyboardButton(text='Количество рефералов на ссылке', callback_data='admin|refscount')
admin_button3 = InlineKeyboardButton(text='Количество рефералов', callback_data='admin|refs')
admin_button4 = InlineKeyboardButton(text='Количество заблокированных', callback_data='admin|blocked')
admin_markup.add(*[admin_button1, admin_button2, admin_button3, admin_button4])



