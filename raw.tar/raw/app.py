from flask import Flask
from flask_sqlalchemy import SQLAlchemy

from telebot import TeleBot


class Config(object):
    SQLALCHEMY_DATABASE_URI = 'sqlite:///main.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False


app = Flask(__name__)
app.config.from_object(Config)
db = SQLAlchemy(app)

token = '1372163267:AAFtMSVJ1TRmS9g2IWxoE7wHrdt0-Qb6Re4'

bot = TeleBot(token)

admins_l = [1076063401]


def admins(fn):
    def wrapped(m):
        if m.from_user.id in admins_l:
            return fn(m)
    return wrapped
