from app import bot
from texts import instruction_text

@bot.message_handler(func = lambda msg: msg.text == 'Инструкция')
def instruction(msg):
    bot.send_message(msg.from_user.id, instruction_text)
